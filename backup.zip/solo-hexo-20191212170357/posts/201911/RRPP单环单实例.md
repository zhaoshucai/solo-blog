title: RRPP单环单实例
date: '2019-11-02 10:57:57'
updated: '2019-11-02 10:57:57'
tags: [HUAWEI, RS, RRPP]
permalink: /articles/2019/11/02/1572667077848.html
---
![](https://img.hacpai.com/bing/20181223.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

❤️ 1、Domain1 Ring1 的控制Vlan为4080。
❤️ 2、拓扑
实验拓扑：
![21.jpg](https://img.hacpai.com/file/2019/11/21-4173ada3.jpg)
**SW A：**
sysname SW A
\#
vlan batch 2 to 4081
\#
rrpp enable
\#
stp region-configuration
 instance 1 vlan 2 to 4081
 active region-configuration
\#
rrpp domain 1
 control-vlan 4080
 protected-vlan reference-instance 1
 ring 1 node-mode master primary-port GigabitEthernet0/0/1 secondary-port Gigabi
tEthernet0/0/2 level 0
 ring 1 enable
\#
interface MEth0/0/1
\#
interface GigabitEthernet0/0/1
 port link-type trunk
 undo port trunk allow-pass vlan 1
 port trunk allow-pass vlan 2 to 4081
 stp disable
\#
interface GigabitEthernet0/0/2
 port link-type trunk
 undo port trunk allow-pass vlan 1
 port trunk allow-pass vlan 2 to 4081
 stp disable
\#
return
**SW B：**
sysname SW B
\#
vlan batch 2 to 4081
\#
rrpp enable
\#
stp region-configuration
 instance 1 vlan 2 to 4081
 active region-configuration
\#
rrpp domain 1
 control-vlan 4080
 protected-vlan reference-instance 1
 ring 1 node-mode transit primary-port GigabitEthernet0/0/1 secondary-port GigabitEthernet0/0/2 level 0
 ring 1 enable
\#
interface GigabitEthernet0/0/1
 port link-type trunk
 undo port trunk allow-pass vlan 1
 port trunk allow-pass vlan 2 to 4081
 stp disable
\#
interface GigabitEthernet0/0/2
 port link-type trunk
 undo port trunk allow-pass vlan 1
 port trunk allow-pass vlan 2 to 4081
 stp disable
\#
return
**SW C：**
sysname SW C
\#
vlan batch 2 to 4081
\#
rrpp enable
\#
stp region-configuration
 instance 1 vlan 2 to 4081
 active region-configuration
\#
rrpp domain 1
 control-vlan 4080
 protected-vlan reference-instance 1
 ring 1 node-mode transit primary-port GigabitEthernet0/0/1 secondary-port GigabitEthernet0/0/2 level 0
 ring 1 enable
\#
interface GigabitEthernet0/0/1
 port link-type trunk
 undo port trunk allow-pass vlan 1
 port trunk allow-pass vlan 2 to 4081
 stp disable
\#
interface GigabitEthernet0/0/2
 port link-type trunk
 undo port trunk allow-pass vlan 1
 port trunk allow-pass vlan 2 to 4081
 stp disable
\#
return
❤️ 3、实验验证：
**SW A:**
![22.jpg](https://img.hacpai.com/file/2019/11/22-7587d423.jpg)
![23.jpg](https://img.hacpai.com/file/2019/11/23-94de7919.jpg)


