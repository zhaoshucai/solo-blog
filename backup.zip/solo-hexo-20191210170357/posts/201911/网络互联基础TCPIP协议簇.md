title: 网络互联基础-TCP/IP 协议簇
date: '2019-11-08 17:10:15'
updated: '2019-11-08 17:10:15'
tags: [HUAWEI, ROS, RS, Cisco]
permalink: /articles/2019/11/08/1573207815134.html
---
TCP/IP(Transmission Control Protocol/Internet Protocol)已成为一个事实上的工业 标准。 TCP/IP是一组协议的代名词，它还包括许多协议，组成了TCP/IP协议簇。 TCP/IP协议簇分为四层，IP位于协议簇的第二层(对应OSI的第三层)，TCP位于协议簇的第 三层(对应OSI的第四层)。 TCP和IP是TCP/IP协议簇的中间两层，是整个协议簇的核心，起到了承上启下的作用。 
##### 1、接口层 
TCP/IP的最低层是接口层，常见的接口层协议有： Ethernet 802.3、Token Ring 802.5、X.25、Frame reley、HDLC、PPP等。 
##### 2、网络层 
网络层包括：IP(Internet Protocol)协议、ICMP(Internet Control Message Protocol) 控制报文协议、ARP(Address Resolution Protocol)地址转换协议、RARP(Reverse ARP)反向 地址转换协议。 
IP是网络层的核心，通过路由选择将下一跳IP封装后交给接口层。IP数据报是无连接服务 。 
ICMP是网络层的补充，可以回送报文。用来检测网络是否通畅。 Ping命令就是发送ICMP的echo包，通过回送的echo relay进行网络测试。 
ARP是正向地址解析协议，通过已知的IP，寻找对应主机的MAC地址。 RARP是反向地址解析协议，通过MAC地址确定IP地址。比如无盘工作站和DHCP服务。 
##### 3、传输层 
传输层协议主要是：传输控制协议TCP(Transmission Control Protocol)和用户数据报协 议UDP(User Datagram rotocol)。 
TCP是面向连接的通信协议，通过三次握手建立连接，通讯时完成时要拆除连接，由于TCP 是面向连接的所以只能用于点对点的通讯。 TCP提供的是一种可靠的数据流服务，采用“带重传的肯定确认”技术来实现传输的可靠 性。TCP还采用一种称为“滑动窗口”的方式进行流量控制，所谓窗口实际表示接收能力，用 以限制发送方的发送速度。 
UDP是面向无连接的通讯协议，UDP数据包括目的端口号和源端口号信息，由于通讯不需要 连接，所以可以实现广播发送。 UDP通讯时不需要接收方确认，属于不可靠的传输，可能会出丢包现象，实际应用中要求 在程序员编程验证。 
##### 4、应用层 
应用层一般是面向用户的服务。如FTP、TELNET、DNS、SMTP、POP3。 
FTP(File Transmision Protocol)是文件传输协议，一般上传下载用FTP服务，数据端口 是20H，控制端口是21H。 
Telnet服务是用户远程登录服务，使用23H端口，使用明码传送，保密性差、简单方便。 
DNS(Domain Name Service)是域名解析服务，提供域名到IP地址之间的转换。 
SMTP(Simple Mail Transfer Protocol)是简单邮件传输协议，用来控制信件的发送、中 转。 
POP3(Post Office Protocol 3)是邮局协议第3版本，用于接收邮件。 
数据格式： 数据帧：帧头＋IP数据包＋帧尾 (帧头包括源和目标主机MAC地址及类型,帧尾是校验字) 
IP数据包：IP头部＋TCP数据信息 (IP头包括源和目标主机IP地址、类型、生存期等) 
IP数据信息：TCP头部+实际数据  (TCP头包括源和目标主机端口号、顺序号、确认号、校 验字等)
