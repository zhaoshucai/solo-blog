title: MikroTik VRRP网关备份配置
date: '2019-11-26 16:23:43'
updated: '2019-11-26 16:24:12'
tags: [MikroTik, VRRP, Gateway, Project]
permalink: /articles/2019/11/26/1574760223510.html
---
拓扑：
![1.jpg](https://img.hacpai.com/file/2019/11/1-92a9d8f0.jpg)
设备配置：
Router_1
1.1、添加eth1（WAN)的接口IP地址:10.10.10.2/24；
![2.jpg](https://img.hacpai.com/file/2019/11/2-c0fe4916.jpg)
1.2、添加eth3（LAN)的接口IP地址:192.168.1.1/24；
1.3、在接口处添加优先级为150的VRRP接口。并配置IP地址为：192.168.1.254/32；
![3.jpg](https://img.hacpai.com/file/2019/11/3-1c2623d0.jpg)
1.4、添加默认路由；
![4.jpg](https://img.hacpai.com/file/2019/11/4-60c4edda.jpg)
1.5、添加地址伪装；
![5.jpg](https://img.hacpai.com/file/2019/11/5-a9e58203.jpg)
1.6、设置DHCP_SERVER,将网关设置为192.168.1.254
![6.jpg](https://img.hacpai.com/file/2019/11/6-d858489f.jpg)

Router_2
2.1、添加eth2（WAN)的接口IP地址:10.10.10.3/24；
2.2、添加eth1（LAN)的接口IP地址:192.168.1.2/24；
2.3、在接口处添加优先级为120的VRRP接口。并配置IP地址为：192.168.1.254/32；
2.4、添加默认路由；
2.5、添加地址伪装；
2.6、设置DHCP_SERVER,将网关设置为192.168.1.254
