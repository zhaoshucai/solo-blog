title: OSI七层
date: '2019-11-04 09:58:53'
updated: '2019-11-04 09:58:53'
tags: [OSI, HUAWEI, MikroTik, RS]
permalink: /articles/2019/11/04/1572836333186.html
---
![1.PNG](https://img.hacpai.com/file/2019/11/1-66f779e9.PNG)

