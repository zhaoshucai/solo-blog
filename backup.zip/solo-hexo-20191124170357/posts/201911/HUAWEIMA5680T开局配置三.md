title: HUAWEI MA5680T 开局配置（三）
date: '2019-11-04 14:53:51'
updated: '2019-11-04 14:53:51'
tags: [HUAWEI, OLT, MA5680T]
permalink: /articles/2019/11/04/1572854031093.html
---
**数据规划：**
![3.PNG](https://img.hacpai.com/file/2019/11/3-4d754586.PNG)
*1、配置流量模板*
    huawei(config)#traffic table ip name ftth_hsi cir 4096 priority 0 priority-policy local-setting
*2、配置GEM port与VLAN映射关系*
    在ONT线路模板中，将用户侧VLAN 100的业务流映射到索引12的GEM port。
    huawei(config)#ont-lineprofile gpon profile-name ftth
    huawei(config-gpon-lineprofile-1)#gem mapping 12 0 vlan 100
    huawei(config-gpon-lineprofile-1)#commit
*3、配置ONT ETH端口VLAN*
    假设ONT通过1号ETH端口接入PC。在ONT业务模板中，将1号ETH端口加入VLAN 100。
    huawei(config)#ont-srvprofile gpon profile-name ftth
    huawei(config-gpon-srvprofile-1)#port vlan eth 1 100
    huawei(config-gpon-srvprofile-1)#commit
**4、配置ONT ETH端口Native VLAN**
    将1号ETH端口的Native VLAN ID配置为100。
    huawei(config)#interface gpon 0/1
    huawei(config-if-gpon-0/1)#ont port native-vlan 0 1 eth 1 vlan 100
*5、创建上网业务VLAN并配置其上行口*
    将上行端口0/19/0加入到VLAN 100中
    huawei(config)#vlan 100 smart
    huawei(config)#port vlan 100 0/19 0
*6、创建业务流*
    业务VLAN为100，GEM Port ID为14，用户侧VLAN为100，使用名称为ftth_hsi的流量模板。
    huawei(config)#service-port vlan 100 gpon 0/1/0 ont 1 gemport 14 multi-serviceuser-vlan 100 inbound traffic-table name ftth_hsi outbound traffic-table name ftth_hsi
*7、保存数据*
    huawei(config)#save

