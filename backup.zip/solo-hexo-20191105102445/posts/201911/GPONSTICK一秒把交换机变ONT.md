title: GPON STICK一秒把交换机变ONT
date: '2019-11-05 10:24:07'
updated: '2019-11-05 10:24:07'
tags: [HUAWEI, OLT, GPONSTICK]
permalink: /articles/2019/11/05/1572924247300.html
---
**设备介绍：**
❤️ GPON STICK 光模块可以充分满足电信级FTTB\ FTTH\ FTTO 设备的要求，可以热插拔到二层以太网交换机 SFP 插槽中工作，整 机就可作为 ONT 甚至 MDU，从而使整机设备可直接联入 GPON 光网络，局端 OLT 只需要像配置普通光猫那样注册 GPON STICK 光模块，该通信设备就可以完成从原 P2P 网络到 PON 网络的接入切换。GPON  STICK 光模块支持 OMCI 标准，可以提供高达 1.25Gbps 的上行链路和下行链路 2.5Gbps 的高速传输速率，还可配合该通信设备支持逻辑标识（LOID）认证、Dying Gasp、PON 链路状态指示、光模块异常发光关断等功能。
**设备的配置:**
❤️ 光口插上模块，光口灯会亮
❤️ 注意：如果不亮的话会有几种情况对交换机的要求：1、光口是否配置成强制要求千兆，2、端口模式为光口模式（有的交换机需要额外配置，请查看确认是否是这个模式）。
❤️ 模块工作正常后，在网页端输入192.168.1.1会跳转至登录界面：
![1.png](https://img.hacpai.com/file/2019/11/1-4ec22419.png)
❤️ 账户：admin  密码：system
![2.png](https://img.hacpai.com/file/2019/11/2-6285561f.png)
❤️ 设备状态查看：
![3.png](https://img.hacpai.com/file/2019/11/3-3ee13797.png)
❤️ GPON设定：
![4.png](https://img.hacpai.com/file/2019/11/4-9887fc5b.png)
❤️ 固件升级（可选）：
![5.png](https://img.hacpai.com/file/2019/11/5-f300c7c3.png)
❤️ 常用命令：
👍 开启Telnet（将命令行复制至浏览器回车即可生效）：[http://192.168.1.1/bd/telnet_open.asp](http://192.168.1.1/bd/telnet_open.asp) 
 注：Telnet默认登录账号/密码：admin/ststem
👍 关闭Telnet（将命令行复制至浏览器回车重启设备即可生效）：http://192.168.1.1/bd/telnet_close.asp
👍 查看设备默认的SN：flash get GPON_SN  
👍 更改设备默认的SN：flash set GPON_SN
👍 查看设备默认MAC：flash get ELAN_MAC_ADDR
👍 更改设备默认MAC：flash set ELAN_MAC_ADDR





