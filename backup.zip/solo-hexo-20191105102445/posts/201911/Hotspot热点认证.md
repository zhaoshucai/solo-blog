title: Hotspot热点认证
date: '2019-11-02 11:07:12'
updated: '2019-11-02 11:07:12'
tags: [ROS, MikroTik, Hotspot]
permalink: /articles/2019/11/02/1572667632529.html
---
❤️ 1、配置设备外部网络
❤️ 2、建立Hotspot端口
![31.jpg](https://img.hacpai.com/file/2019/11/31-49eff2ec.jpg)
![32.jpg](https://img.hacpai.com/file/2019/11/32-072dbfc5.jpg)
❤️ 3、配置Hotspo
![33.jpg](https://img.hacpai.com/file/2019/11/33-e0d0c4db.jpg)
![34.jpg](https://img.hacpai.com/file/2019/11/34-0a5437fe.jpg)
根据提示选择建立的Hotspot端口并填写准确的配置信息。
❤️ 4、修改Hotspot认证界面默认图标
替换flash/hotspot/img里的文件即可
❤️ 5、苹果手机可能会出现连接热点后无法自动弹出认证页面，请添加一下规则：
/ip hotspot walled-garden add dst-host=*.apple.com.edgesuite.net
/ip hotspot walled-garden add dst-host=*.apple.com
/ip hotspot walled-garden add dst-host=*.akadns.org
/ip hotspot walled-garden add dst-host=*.thinkdifferent.us
/ip hotspot walled-garden add dst-host=*.akamai.net
/ip hotspot walled-garden add dst-host=*.edgekey.net
/ip hotspot walled-garden add dst-host=*.akamaiedge.net
/ip hotspot walled-garden add dst-host=*.ibook.info
/ip hotspot walled-garden add dst-host=*.appleiphonecell.com
/ip hotspot walled-garden add dst-host=*.airport.us
/ip hotspot walled-garden add dst-host=*.itools.info
/ip hotspot walled-garden add dst-host=*.akadns.net




