title: Zabbix+Grafana大型网络监控环境搭建（二）
date: '2019-11-08 15:03:15'
updated: '2019-11-08 15:03:15'
tags: [Zabbix, Grafana, Centos7, Project]
permalink: /articles/2019/11/08/1573200195915.html
---
❤️ **安装Apache2/httpd**
1、安装Apache2/httpd 
#yum -y install httpd 
2、启动服务并设置开机启动 
#systemctl start httpd 
#systemctl enable httpd 
3、检查是否安装成功 
#netstat -plntu 
注：若提示bash: netstat: command not found请安装一下插件： 
#yum search netstat 
#yum -y install net-tools
![4.png](https://img.hacpai.com/file/2019/11/4-c86fadcd.png)
❤️ **配置PHP7.2**
1、添加PHP到系统 
#yum -y install epel-release #rpm -Uvh [https://mirror.webtatic.com/yum/el7/webtatic-release.rpm]
2、安装PHP7.2 
#yum -y install mod_php72w php72w-cli php72w-common php72w-devel php72w-pear php72w-gd php72w-mbstring php72w-mysql php72w-xml php72w-bcmath 
3、编辑默认的php.ini文件 
#vim /etc/php.ini 修改以下参数 
max_execution_time = 600           ----384 
max_input_time = 600                  ----394 
memory_limit = 256M                  ----405 
post_max_size = 32M                   ----672 
upload_max_filesize = 16M          ----800 
date.timezone = Asia/Phnom_Penh       ----878 
注：vim常见命令 
set nu!    ----显示行号 
：wq!      ----强制保存 
4、重启httpd服务 
#systemctl restart httpd

