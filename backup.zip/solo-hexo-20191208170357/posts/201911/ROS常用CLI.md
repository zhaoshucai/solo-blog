title: ROS常用CLI
date: '2019-11-02 11:38:23'
updated: '2019-11-02 11:38:23'
tags: [ROS, MikroTik]
permalink: /articles/2019/11/02/1572669503530.html
---
| 命令 | 解释 | 
| --- | --- | 
| add | 加 | 
| comment | 备注规则信息 | 
| disable | 禁用规则 | 
| enable | 启用规则 | 
| print | 显示所有规则 | 
| print detail | 详细显示所有规则 | 
| remove | 移除特定规则 | 
| set | 输入更改参数 | 
| ？| 显示所有可执行命令 | 
| .. | 水平移动一个菜单 |
| / | 移动至顶层菜单| 
| add | 加 | 
| add | 加 | 
| add | 加 |  
注：使用export命令可以无密导出所需配置。
