title: Zabbix+Grafana大型网络监控环境搭建(三）
date: '2019-11-08 15:13:28'
updated: '2019-11-08 15:13:28'
tags: [Zabbix, Project, Grafana, Centos7]
permalink: /articles/2019/11/08/1573200808396.html
---
❤️ **Zabbix-agent的配置**
1、编辑Zabbix-agent配置文件 
#vim /etc/zabbix/zabbix_agentd.conf 
修改以下配置 
Server=127.0.0.1 
ServerActive=127.0.0.1 
Hostname=localhost.localdomain 
2、启动zabbix-agent并设置为开机自动启动 
#systemctl start zabbix-agent 
#systemctl enable zabbix-agent 
3、检查zabbix-agent是否启动 
#systemctl status zabbix-agent
![5.png](https://img.hacpai.com/file/2019/11/5-6c03282b.png)
❤️ **安装Grafana **
1、下载Grafana 
#wget https://dl.grafana.com/oss/release/grafana-6.1.6-1.x86_64.rpm注：若提示错误请安装wget 
#yum -y install wget 
#yum localinstall grafana-6.1.6-1.x86_64.rpm 
2、安装Zabbix插件： 
#grafana-cli plugins install alexanderzobnin-zabbix-app 
3、启动Grafana 
#service grafana-server start 
#chkconfig grafana-server on 
4、检查防火墙配置是否允许Grafana端口通过 
#firewall-cmd --list-ports 
5、配置防火墙允许Grafana端口通过 
#firewall-cmd --add-port=3000/tcp --zone=public --permanent 
#firewall-cmd --reload 
6、检查配置是否成功 
#firewall-cmd --list-ports
![6.png](https://img.hacpai.com/file/2019/11/6-1bfbbc64.png)
8、zabbix后台API接口地址http://ZabbixserverIP/zabbix/api_jsonrpc.php
❤️ **zabbix设置为中文后显示乱码** 
1、查找真在使用的字体包位置 
#cd /usr/share/fonts/dejavu 
#ls 
2、备份原有字体 
#mv /usr/share/fonts/dejavu/DejaVuSans.ttf /tmp 
3、安装传输软件 
#yum -y install lrzsz 
4、上传需要更换的字体到服务器 
#rz 
5、替换字体文件 
#mv simhei.ttf /usr/share/fonts/dejavu/DejaVuSans.ttf
