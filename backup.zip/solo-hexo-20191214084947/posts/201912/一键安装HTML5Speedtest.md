title: 一键安装HTML5 Speedtest
date: '2019-12-13 18:16:06'
updated: '2019-12-13 18:16:06'
tags: [Project]
permalink: /articles/2019/12/13/1576235766490.html
---
使用Docker安装：

❤️ 首先安装 Docker
curl -sSL https://get.docker.com/ | sh 
systemctl start docker 
systemctl enable docker

❤️ 安装HTML5 Speedtest
docker run -d -p 80:80 ilemonrain/html5-speedtest:alpine

❤️ 参数详解
-t:启动后显示日志，可用Ctrl+C转入后台运行 
-d:后台模式启动 
-p:80:80 镜像映射端口,可以根据服务器实际情况修改映射端口

完成以上步骤后浏览器访问服务器IP地址即可，若无法访问请在服务器放行80端口。



