title: H3C IRF堆叠实施
date: '2019-11-20 10:18:24'
updated: '2019-11-20 10:31:16'
tags: [H3C, Project, IRF, 堆叠]
permalink: /articles/2019/11/20/1574219904478.html
---
1、实施拓扑
![1.jpg](https://img.hacpai.com/file/2019/11/1-d622a9a1.jpg)
2、实施步骤
2.1、IRF1实施配置
设置IRF1的IRF优先级
[IRF1]irf member 1 priority 32 
~~Master 角色选举规则
1、成员优先级较大的优先（1-32）
2、系统运行时间长的优先
3、成员桥MAC小的优先~~
关闭IRF 1和IRF 2的互联接口
[IRF1]interface range Ten-GigabitEthernet 1/0/50 to Ten-GigabitEthernet 1/0/51
[IRF1-if-range]shutdown
[IRF1-if-range]quit
设置IRF1的逻辑接口2，并加入物理接口
[IRF1]irf-port 1/2
[IRF1-irf-port1/2]port group interface Ten-GigabitEthernet 1/0/50
[IRF1-irf-port1/2]port group interface Ten-GigabitEthernet 1/0/51
[IRF1-irf-port1/2]quit
开启物理接口，并保存设备
[IRF1]interface range Ten-GigabitEthernet 1/0/50 to Ten-GigabitEthernet 1/0/51
[IRF1-if-range]undo shutdown
[IRF1-if-range]quit
[IRF1]save
2.2、IRF2实施配置
修改IRF2成员编号
[IRF2]irf member 1 renumber 2
保存修改信息，并重启设备
[IRF2]save
[IRF2]quit
<IRF2>reboot 
关闭IRF 2和IRF 1的互联接口
[IRF2]interface range Ten-GigabitEthernet 2/0/50 to Ten-GigabitEthernet 2/0/51
[IRF2-if-range]shutdown
[IRF2-if-range]quit
设置IRF1的逻辑接口1，并加入物理接口
[IRF1]irf-port 2/1
[IRF1-irf-port2/1]port group interface Ten-GigabitEthernet 1/0/50
[IRF1-irf-port2/1]port group interface Ten-GigabitEthernet 1/0/51
[IRF1-irf-port2/1]quit
开启物理接口，并保存设备
[IRF2]interface range Ten-GigabitEthernet 2/0/50 to Ten-GigabitEthernet 2/0/51
[IRF2-if-range]undo shutdown
[IRF2-if-range]quit
[IRF2]save
2.3、激活IRF1的IRF配置
[IRF1]irf-port-configuration active
2.4、激活IRF2的IRF配置
[IRF2]irf-port-configuration active
3、等待设备自动重启后查看配置是否成功
[IRF1]display irf
![2.jpg](https://img.hacpai.com/file/2019/11/2-eb2fa8a7.jpg)
[IRF1]display irf link
![3.jpg](https://img.hacpai.com/file/2019/11/3-5f90345c.jpg)












