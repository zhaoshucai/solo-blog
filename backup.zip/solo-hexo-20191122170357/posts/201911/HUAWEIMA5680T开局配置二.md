title: HUAWEI MA5680T 开局配置（二）
date: '2019-11-04 14:44:31'
updated: '2019-11-04 14:44:48'
tags: [HUAWEI, OLT, MA5680T]
permalink: /articles/2019/11/04/1572853471835.html
---
**数据规划：**
![2.PNG](https://img.hacpai.com/file/2019/11/2-002dfb15.PNG)
**操作步骤：**
配置GPON ONT模板。
GPON ONT模板包括DBA模板、线路模板、业务模板、告警模板。
❤️ DBA模板：DBA模板描述了GPON的流量参数，T-CONT通过绑定DBA模板进行动态分配带宽，提高上行带宽利用率。
❤️ 线路模板：线路模板描述了T-CONT和DBA模板的绑定关系、业务流的QoS模式、GEM Port与ONT侧业务的映射关系等。
❤️ 业务模板：业务模板为采用OMCI方式管理的ONT提供了业务配置渠道。
❤️ 告警模板：告警模板设置一系列告警门限参数，用于对激活的ONT线路进行性能统计监控，当某个统计量达到告警门限时，就通知主机，并向日志主机和网管发送告警信息
*1、配置DBA模板*
huawei(config)#dba-profile add profile-name ftth_dba type3 assure 8192 max 20480
*2、配置ONT线路模板*
创建模板名称为ftth的GPON ONT线路模板，并绑定DBA模板。
huawei(config)#ont-lineprofile gpon profile-name ftth
huawei(config-gpon-lineprofile-1)#tcont 4 dba-profile-name ftth_dba
huawei(config-gpon-lineprofile-1)#gem add 11 eth tcont 4
huawei(config-gpon-lineprofile-1)#gem add 12 eth tcont 4
注：此项配置完成后需要提交，才可使配置生效
huawei(config-gpon-lineprofile-1)#commit
*3、配置ONT业务模板*
创建模板名称为ftth的GPON ONT业务模板。配置ETH端口和POTS端口能力集为adaptive，系统将根据上线的ONT的实际能力进行自适应。
huawei(config)#ont-srvprofile gpon profile-name ftth  
huawei(config-gpon-srvprofile-1)#ont-port eth adaptive pots adaptive
huawei(config-gpon-lineprofile-1)#commit
*4、增加光猫（此处使用自动发现）*
huawei(config)#interface gpon 0/1
huawei(config-if-gpon-0/1)#port 0 ont-auto-find enable
huawei(config-if-gpon-0/1)#display ont autofind 0     //该命令会显示通过分光器接入到该GPON端口的所有ONT的信息
huawei(config-if-gpon-0/1)#ont confirm 0 ontid 1 sn-auth 3230313126595540 omci ont-lineprofile-name ftth ont-srvprofile-name ftth
*5、确认ONT是否上线成功*
 huawei(config-if-gpon-0/1)#display ont info 0 1

     --------------------------------------------------------------------- 

     F/S/P                : 0/1/0                                          

     ONT-ID               : 1                                              

     Control flag         : active    //说明ONT已经激活                 

     Run state            : online    //说明ONT已经正常在线              

     Config state         : normal    //说明ONT配置恢复状态正常           

     Match state          : match     //说明ONT绑定的能力模板与ONT实际能力一致
