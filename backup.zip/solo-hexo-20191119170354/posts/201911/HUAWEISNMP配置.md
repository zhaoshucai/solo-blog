title: HUAWEI SNMP 配置
date: '2019-11-19 16:26:36'
updated: '2019-11-19 16:26:36'
tags: [HUAWEI, RS, SNMP]
permalink: /articles/2019/11/19/1574155596048.html
---
1、开启snmp
snmp-agent
2、配置snmp版本号
snmp-agent sys-info version v2c
3、配置snmp mib-view
snmp-agent mib-view ~~HUAWEI~~ include ~~iso~~
4、配置snmp读写团体名
snmp-agent community read ~~password~~ mib-view ~~iso~~
snmp-agent community write ~~password~~ mib-view ~~iso~~ 
5、配置snmp target-host
snmp-agent target-host trap-hostname ~~HUAWEI~~ address ~~192.168.0.1~~ udp-port 162 trap-paramsname ~~HUAWEI~~
6、配置snmp trap 发送端口  
snmp-agent trap source ~~Vlanif10~~
7、开启snmp trap
snmp-agent trap enable

