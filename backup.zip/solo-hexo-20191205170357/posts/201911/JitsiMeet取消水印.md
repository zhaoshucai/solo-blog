title: Jitsi Meet 取消水印
date: '2019-11-05 10:29:47'
updated: '2019-11-05 10:32:31'
tags: [Meet, Jitsi, Project]
permalink: /articles/2019/11/05/1572924587482.html
---
1、进入水印照片目录  
cd /usr/share/jitsi-meet/images/
2、上传水印照片
安装传输软件
yum -y install lrzsz
注：安装完成后在目录下输入rz即可开始上传文件  
3、重启nginx或者服务器，即可完成水印照片修改。
