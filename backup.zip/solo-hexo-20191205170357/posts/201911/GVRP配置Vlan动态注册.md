title: GVRP配置（Vlan动态注册）
date: '2019-11-02 11:27:38'
updated: '2019-11-02 11:27:38'
tags: [HUAWEI, RS, GVRP]
permalink: /articles/2019/11/02/1572668858723.html
---
❤️ 需求：
1、SW A配置GVRP功能并配置接口注册模式为Normal，以简化配置。
2、SW C配置GVRP功能并将与SW B相连的接口的注册模式配置为Fixed，以控制只允许SW C配置的VLAN通过。
❤️ 拓扑:
![41.png](https://img.hacpai.com/file/2019/11/41-320f35bd.png)
❤️ 配置文件：
**SW A:**
\#
sysname SW A
\#
gvrp
\#
interface GigabitEthernet0/0/1
 port link-type trunk
 port trunk allow-pass vlan 2 to 4094
 gvrp
**SW B:**
\#
sysname SW B
\#
gvrp
\#
interface GigabitEthernet0/0/1
 port link-type trunk
 port trunk allow-pass vlan 2 to 4094
 gvrp
\#
interface GigabitEthernet0/0/2
 port link-type trunk
 port trunk allow-pass vlan 2 to 4094
 gvrp
**SW C：**
\#
sysname SW C
\#
gvrp
\#
interface GigabitEthernet0/0/1
 port link-type trunk
 port trunk allow-pass vlan 2 to 4094
 gvrp
 gvrp registration fixed


