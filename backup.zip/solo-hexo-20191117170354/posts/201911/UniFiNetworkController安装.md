title: UniFi Network Controller 安装
date: '2019-11-08 15:25:52'
updated: '2019-11-08 15:25:52'
tags: [UniFi, Project, Controller, Ubuntu]
permalink: /articles/2019/11/08/1573201552054.html
---
❤️ echo 'deb [http://www.ubnt.com/downloads/unifi/debian](http://www.ubnt.com/downloads/unifi/debian) stable ubiquiti' | sudo tee /etc/apt/sources.list.d/100-ubnt-unifi.list
❤️ sudo apt-key adv --keyserver keyserver.ubuntu.com --recv 06E85760C0A52C50
❤️ echo "deb [http://repo.mongodb.org/apt/ubuntu precise/mongodb-org/3.0](http://repo.mongodb.org/apt/ubuntu%20precise/mongodb-org/3.0) multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-3.0.list
❤️ sudo apt-key adv --keyserver hkp://keyserver.ubuntu.com:80 --recv 9ECBEC467F0CEB10
❤️ sudo apt-get -y update & apt-get -y upgrade
❤️ sudo apt-get install -y openjdk-8-jdk
❤️ sudo apt-get install -y mongodb-org
❤️ sudo apt-get install -y unifi
❤️ 对外端口
(TCP)8443,6789,8843,8880,8080,53501
(UDP)3478
❤️ #echo "mongodb-org hold" | sudo dpkg --set-selections
❤️ #echo "mongodb-org-server hold" | sudo dpkg --set-selections
❤️ #echo "mongodb-org-shell hold" | sudo dpkg --set-selections
❤️ #echo "mongodb-org-mongos hold" | sudo dpkg --set-selections
❤️ #echo "mongodb-org-tools hold" | sudo dpkg --set-selections
~~注：启动默认防火墙
sudo ufw enable
使用默认配置
sudo ufw default deny
允许端口
ufw allow port
删除端口
ufw delete allow port
查看防火墙状态
ufw status~~
❤️ AP添加远程管理（命令行）
set-inform http://控制器IP地址:8080/inform
