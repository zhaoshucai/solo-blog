title: Openwrt 2.32 模板
date: '2019-11-08 15:47:04'
updated: '2019-11-08 15:47:04'
tags: [Openwrt, Project, ROS]
permalink: /articles/2019/11/08/1573202824716.html
---
1、模板测试环境为Vmware ESXI6.5 
2、CPU 2vCPUs 
3、内存配置2GB 
4、存储空间4GB 
5、koolss插件已安装 
6、V2ray插件已安装 LAN口采取DHCP模式。 
WEB登录账号：root 
WEB登录密码：openwrt 
链接：https://pan.baidu.com/s/1j2kR7TZtBcSQaGyHSu17UQ 提取码：2e81
