title: HUAWEI MA5680T 开局配置（一）
date: '2019-11-04 10:21:38'
updated: '2019-11-04 10:21:38'
tags: [HUAWEI, OLT, MA5680T]
permalink: /articles/2019/11/04/1572837698771.html
---
\>>User name:~~root~~
\>>User password:~~admin~~
Ma5680T>enable
Ma5680T#config
Ma5680T(config)#sysname ~~XXX~~  //修改系统名称
Ma5680T(config)#time YY-HH-DD 00:00:00  //修改系统时间
Ma5680T(config)#switch language-mode  //切换系统语言模式
可选配置：
MA5680T (config) #terminal user name   //添加操作用户
-User Name(length<6,15>):~~XXXX~~      //设置用户名
-User Password(length<6,15>):~~XXXX~~     //要求输入密码.输入部分实际为不可见的
-Confirm Password(length<6,15>): ~~XXXX~~       //要求再次确认一遍密码
-User profile name(<=15 chars)[root]:root         //输入用户管理级别
-User's Level:
--1. Common User  2. Operator  3. Administrator        //选择用户权限
-Permitted Reenter Number(0--4):1      //设置此用户名可重复登录次数，一般要求为1次
-User's Appended Info(<=30 chars):~~XXXXX~~   //添加描述，可不设置。
Ma5680T(config)#display board 0  //查看所有单板状态
Ma5680T(config)#board confirm 0  //确认所有单板
Ma5680T(config)#vlan ~~X~~ smart  //创建网管VLAN
Ma5680T(config)#port vlan ~~X~~ ~~X~~/~~X~~ 0  //透传VLAN到上行口
Ma5680T(config)#vlan ~~X~~ to ~~X~~ smart  //创建业务VLAN
Ma5680T(config)#interface vlanif ~~X~~
Ma5680T(config-vlanif~~X~~)#ip address ~~X.X.X.X X.X.X.X~~  //配置管理地址
Ma5680T(config)#ip route-static ~~X.X.X.X X.X.X.X X.X.X.X~~  //配置路由信息

​
