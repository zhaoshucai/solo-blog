title: 使用Jitsi Meet创建自己的视频会议服务器
date: '2019-11-08 15:55:17'
updated: '2019-11-08 15:55:17'
tags: [Jitsi, Meet, Project, Ubuntu]
permalink: /articles/2019/11/08/1573203317421.html
---
Jitsi是一组开源项目，允许您为您的团队构建安全的视频会议系统。 Jitsi项目的核心组件是Jitsi VideoBridge和Jitsi Meet。 有基于Jitsi项目的免费和高级服务，如HipChat，Stride，Highfive，Comcast。 Jitsi Meet是Jitsi家族的核心，它是一个开源JavaScript WebRTC应用程序，允许您构建和部署可扩展的视频会议。 它建立在一些jitsi项目之上，包括jitsi videobridge，jifoco和jigasi。 它具有视频会议功能，例如桌面和演示文稿共享，邀请新会员加入视频会议，只需一个链接，并使用Etherpad启用协作编辑。
**第1步 - 安装Java OpenJDK**
添加OpenJDK PPA存储库并使用下面的apt命令安装Java OpenJDK。 
sudo add-apt-repository ppa:openjdk-r/ppa 
sudo apt install openjdk-8-jre-headless -y
在所有安装完成后检查Java OpenJDK版本。
 java -version
**第2步 - 安装Nginx**
使用下面的apt命令安装Nginx Web服务器。 
sudo apt install nginx -y 
现在启动nginx服务并使其在系统启动时每次启动。 
systemctl start nginx systemctl enable nginx
**第3步 - 安装Jitsi Meet**
使用以下命令将jitsi密钥和存储库添加到系统。 
sudo wget -qO - https://download.jitsi.org/jitsi-key.gpg.key | apt-key add - sudo echo 'deb https://download.jitsi.org stable/' >>/etc/apt/sources.list.d/jitsi-stable.list 
现在更新存储库并安装jitsi meet packages。 
sudo apt update sudo apt install jitsi-meet -y
注意：中途需要输入域名以及同意生成SSL证书 输入域名或IP
生成新的证书签名
**第4步 - 生成Letsencrypt SSL证书**
/usr/share/jitsi-meet/scripts/install-letsencrypt-cert.sh
注意：中途需要输入邮箱生成SSL证书
**第5步 - 设置UFW防火墙**
通过运行UFW命令打开这些端口。 
ufw allow ssh 
ufw allow http 
ufw allow https 
ufw allow in 4443/tcp 
ufw allow in 5280/tcp 
ufw allow in 10000:20000/udp
现在启用UFW防火墙并重新加载所有配置。 
ufw enable 
ufw status
**第6步 - 配置ICE NAT穿透**
在配置文件/etc/jitsi/videobridge/sip-communicator.properties中增加如下配置:
org.ice4j.ice.harvest.NAT_HARVESTER_LOCAL_ADDRESS=<Local.IP.Address>
org.ice4j.ice.harvest.NAT_HARVESTER_PUBLIC_ADDRESS=<Public.IP.Address>
其中<Local.IP.Address>为虚拟机内网本机IP地址，<Public.IP.Address>为公有云分配的公网IP地址。配置完成后需要重启下jitsi-videobridge: service jitsi-videobridge restart
**第7步 - 配置STUN服务器**
需要修改配置文件/etc/jitsi/meet/example.com-config.js，找到stunServers配置项，在前面新增如下两个服务器配置：
{ urls: 'stun:stun.freeswitch.org' },
{ urls: 'stun:stun.ideasip.com' },
修改后的配置:
// The STUN servers that will be used in the peer to peer connectionsstunServers: [    
{ urls: 'stun:stun.freeswitch.org' },   
{ urls: 'stun:stun.ideasip.com' },  
{ urls: 'stun:stun.l.google.com:19302' },   
{ urls: 'stun:stun1.l.google.com:19302' },   
{ urls: 'stun:stun2.l.google.com:19302' }],
**第8步 - 测试**
浏览器输入安装时设置的域名或IP，即可进入。
注：卸载重装：
apt-get purge jigasi jitsi-meet jitsi-meet-web-config jitsi-meet-prosody jitsi-m
