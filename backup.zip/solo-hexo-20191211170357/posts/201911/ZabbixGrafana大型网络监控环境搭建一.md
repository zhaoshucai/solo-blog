title: Zabbix+Grafana大型网络监控环境搭建(一）
date: '2019-11-08 14:55:06'
updated: '2019-11-08 14:55:44'
tags: [Zabbix, Grafana, Project, Centos7]
permalink: /articles/2019/11/08/1573199706799.html
---
❤️ **Centos系统的安装**
1、选择最小化安装系统。 
2、设置系统IP为静态（个人建议） 
~~HWADDR=00:0C:29:8D:24:73 
TYPE=Ethernet BOOTPROTO=static  #启用静态IP地址 DEFROUTE=yes 
PEERDNS=yes 
PEERROUTES=yes 
IPV4_FAILURE_FATAL=no 
IPV6INIT=yes 
IPV6_AUTOCONF=yes 
IPV6_DEFROUTE=yes 
IPV6_PEERDNS=yes 
IPV6_PEERROUTES=yes 
IPV6_FAILURE_FATAL=no 
NAME=eno16777736 
UUID=ae0965e7-22b9-45aa-8ec9-3f0a20a85d11 
ONBOOT=yes  #开启自动启用网络连接 
IPADDR0=192.168.21.128  #设置IP地址 
PREFIXO0=24  #设置子网掩码 
GATEWAY0=192.168.21.2  #设置网关 
DNS1=8.8.8.8  #设置主DNS 
DNS2=8.8.4.4  #设置备DNS 
:wq!  #保存退出~~
❤️ **Zabbix安装**
1、下载Zabbix # rpm -Uvh https://repo.zabbix.com/zabbix/4.0/rhel/7/x86_64/zabbix-release-4.0-1.el7.noarch.rpm（官网选择最新版）
2、安装Zabbix server，Web前端，agent 
#yum -y install zabbix-server-mysql zabbix-web-mysql zabbix-agent 
3、安装数据库 
3.1、下载并安装Mysql 
#yum -y install mysql 
#yum -y install mariadb-server mariadb 
#yum -y install mysql-devel 
注： mariadb数据库的相关命令是：   
#systemctl start mariadb  #启动MariaDB   
#systemctl stop mariadb  #停止MariaDB   
#systemctl restart mariadb  #重启MariaDB   
#systemctl enable mariadb  #设置开机启动 
3.2、确认Mysql是否启动 
#ss -tanl
![1.png](https://img.hacpai.com/file/2019/11/1-ed8f829f.png)
3.3、创建一个数据库账户 
#mysql -uroot -p 
mysql> create database zabbix character set utf8 collate utf8_bin; mysql> grant all privileges on zabbix.* to zabbix@localhost identified by 'zabbix'; 
Mysql>FLUSH PRIVILEGES ; 
mysql> quit; 
附： 删除多余账户 
#mysql 
Mysql>use mysql 
Mysql>Delete FROM user Where User='zbxusr' and Host='localhost'; Mysql>FLUSH PRIVILEGES ; 
3.4、查看账户是否创建成功 
#mysql 
Mysql>use mysql 
Mysql>select host,user,password from user;
![2.png](https://img.hacpai.com/file/2019/11/2-acb804e0.png)
4、导入数据库 
#zcat /usr/share/doc/zabbix-server-mysql*/create.sql.gz | mysql -uzabbix -p zabbix 
5、检查数据是否导入成功 
#mysql 
MariaDB [(none)]> use zabbix; 
MariaDB [zabbix]> show tables; 
6、配置Zabbix server数据库 
#cd /etc/zabbix/ Vim zabbix_server.conf 修改一下参数 PidFile=/var/run/zabbix/zabbix_server.pid 
DBHost=localhost DBName=zabbix 
DBUser=数据库账号 
DBPassword=数据库密码 
7、关闭服务器Selinux 
临时： 
#setenforce 0 
#getenforce 
永久： 
修改/etc/selinux/config 文件 
将SELINUX=enforcing改为SELINUX=disabled 
8、启动Zabbix服务器 
#systemctl restart zabbix-server 
检查服务是否启动 
#ss -tanlp
![3.png](https://img.hacpai.com/file/2019/11/3-cbd66697.png)

