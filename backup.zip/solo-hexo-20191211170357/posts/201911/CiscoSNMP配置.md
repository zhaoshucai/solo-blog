title: Cisco SNMP 配置
date: '2019-11-19 17:06:10'
updated: '2019-11-19 17:11:01'
tags: [Cisco, RS, SNMP]
permalink: /articles/2019/11/19/1574157970638.html
---
1、配置snmp读写团体名
snmp-server community ~~huawei~~ RO
snmp-server community ~~huawei~~ RW
2、配置snmp host及版本
snmp-server host ~~192.168.0.1~~ version 2c ~~huawei~~
3、配置snmp tarp发送端口
snmp-server trap-source ~~Vlanif10~~
4、开启链路发现
特权模式：
lldp run 
