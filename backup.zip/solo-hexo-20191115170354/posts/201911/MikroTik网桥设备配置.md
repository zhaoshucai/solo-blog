title: MikroTik 网桥设备配置
date: '2019-11-13 16:04:24'
updated: '2019-11-13 16:04:24'
tags: [MikroTik, ROS, Project]
permalink: /articles/2019/11/13/1573635864028.html
---
❤️ 首先将设备接上你的二层网络。连接好设备之后，使用 winbox 软件扫描登陆设备，根据序号操作如下图：
(注意，同一个二层网络下的设备才能被扫描到)
![1.png](https://img.hacpai.com/file/2019/11/1-edb045dc.png)
❤️ 登陆设备之后如下图，点击按钮清空设备默认配置
![2.png](https://img.hacpai.com/file/2019/11/2-f6627dd1.png)
❤️ 新建桥
![3.png](https://img.hacpai.com/file/2019/11/3-1756813f.png)
❤️ 将以太网口和无线口加入桥接口
![4.png](https://img.hacpai.com/file/2019/11/4-2bcb0e08.png)
![5.png](https://img.hacpai.com/file/2019/11/5-98d09a82.png)
❤️ 配置完成后如下图
![6.png](https://img.hacpai.com/file/2019/11/6-21656865.png)
❤️ 接下来给设备分配一个管理 IP，以便维护登陆使用，IP 可分配跟网络不同网段，不冲突就好。下图以分配 192.168.88.2 为例，输入 IP 后记得加上子网掩码，接口选择 bridge1
![7.png](https://img.hacpai.com/file/2019/11/7-22e3c4ea.png)
❤️ 接下来配置无线网卡参数，先打开无线口
![8.png](https://img.hacpai.com/file/2019/11/8-22d71e2f.png)
❤️ 进一步配置无线参数，点对点发射端模式设置为 **bridge**，点对多点发射端模式设置为 **AP bridge**，无线的频率可根据环境自行选择，下图默认为 5180，SSID 即 wifi 信号名字，可自行修改（如果是 AC 的网桥，则把 band 选为 5G-only-ac，channel width 选为 20/40/80MHz）
![9.png](https://img.hacpai.com/file/2019/11/9-43e7919e.png)
❤️ 最后点击 HT 选项卡，让红框内的 4 个 chain 都勾选上，OK 之后发射端就配置完成了
![10.png](https://img.hacpai.com/file/2019/11/10-d88c7aa7.png)
❤️ 接下来配置接收端，大部分配置都一样，登陆设备之后操作如下：
![11.png](https://img.hacpai.com/file/2019/11/11-3c69a1e0.png)
![12.png](https://img.hacpai.com/file/2019/11/12-f8be6b96.png)
![13.png](https://img.hacpai.com/file/2019/11/13-b1008218.png)![14.png](https://img.hacpai.com/file/2019/11/14-5865ddf1.png)
❤️ 同样是在 bridge 接口添加管理 IP，接收端的 IP 为 192.168.88.3/24
![15.png](https://img.hacpai.com/file/2019/11/15-2ca8df1f.png)![16.png](https://img.hacpai.com/file/2019/11/16-45b86248.png)
❤️ 接收端在这里点击 Scan 扫描发射端信号
![17.png](https://img.hacpai.com/file/2019/11/17-a3bdd4a2.png)
❤️ 选择刚刚发射点设置的 SSID，点击连接
![18.png](https://img.hacpai.com/file/2019/11/18-d07447e9.png)
❤️ 然后将无线参数做适当修改，无线模式选择 **station bridge**，其余如下图红框，点击 OK 配置完毕
![19.png](https://img.hacpai.com/file/2019/11/19-71377de1.png)![20.png](https://img.hacpai.com/file/2019/11/20-b9ec401b.png)
❤️ 点对多点的接收端配置跟点对点一致，只是配置多个接收端而已。❤️ 配置完成后，winbox 可直接扫描到所有设备如下
![21.png](https://img.hacpai.com/file/2019/11/21-1caa2b27.png)




















