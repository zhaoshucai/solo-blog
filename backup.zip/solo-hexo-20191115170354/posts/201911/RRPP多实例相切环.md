title: RRPP多实例相切环
date: '2019-11-02 10:42:30'
updated: '2019-11-02 10:59:59'
tags: [HUAWEI, RS, RRPP]
permalink: /articles/2019/11/02/1572666150013.html
---
![](https://img.hacpai.com/bing/20180309.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

❤️ 1、Domain1 Ring1 的控制Vlan为4082；Domain2 Ring2的控制Vlan为4080。
❤️ 2、拓扑
实验配置：
![1.jpg](https://img.hacpai.com/file/2019/11/1-032a14d8.jpg)
**SW A :**
\#
vlan batch 2 to 4081
\#
rrpp enable
\#
stp region-configuration
 instance 2 vlan 2 to 4081
 active region-configuration
\#
rrpp domain 2
 control-vlan 4080
 protected-vlan reference-instance 2
 timer hello-timer 3 fail-timer 10
 ring 2 node-mode master primary-port GigabitEthernet0/0/1 secondary-port GigabitEthernet0/0/2 level 0
 ring 2 enable
\#
interface GigabitEthernet0/0/1
 port link-type trunk
 undo port trunk allow-pass vlan 1
 port trunk allow-pass vlan 2 to 4081
 stp disable
\#
interface GigabitEthernet0/0/2
 port link-type trunk
 undo port trunk allow-pass vlan 1
 port trunk allow-pass vlan 2 to 4081
 stp disable
\#
return
**SW B:**
\#
vlan batch 2 to 4081
\#
rrpp enable
\#
diffserv domain default
\#
stp region-configuration
 instance 2 vlan 2 to 4081
 active region-configuration
\#
rrpp domain 2
 control-vlan 4080
 protected-vlan reference-instance 2
 timer hello-timer 3 fail-timer 10
 ring 2 node-mode transit primary-port GigabitEthernet0/0/1 secondary-port GigabitEthernet0/0/2 level 0
 ring 2 enable
\#
interface GigabitEthernet0/0/1
 port link-type trunk
 undo port trunk allow-pass vlan 1
 port trunk allow-pass vlan 2 to 4081
 stp disable
\#
interface GigabitEthernet0/0/2
 port link-type trunk
 undo port trunk allow-pass vlan 1
 port trunk allow-pass vlan 2 to 4081
 stp disable
\#
return
**SW C :**
\#
vlan batch 2 to 4083
\#
rrpp enable
\#
stp region-configuration
 instance 1 vlan 4082 to 4083
 instance 2 vlan 4080 to 4081
 active region-configuration
\#
rrpp domain 1
 control-vlan 4082
 protected-vlan reference-instance 1
 timer hello-timer 2 fail-timer 7
 ring 1 node-mode transit primary-port GigabitEthernet0/0/1 secondary-port Gigab
itEthernet0/0/2 level 0
 ring 1 enable
rrpp domain 2
 control-vlan 4080
 protected-vlan reference-instance 2
 timer hello-timer 3 fail-timer 10
 ring 2 node-mode transit primary-port GigabitEthernet0/0/3 secondary-port Gigab
itEthernet0/0/4 level 0
 ring 2 enable
\#
interface GigabitEthernet0/0/1
 port link-type trunk
 undo port trunk allow-pass vlan 1
 port trunk allow-pass vlan 2 to 4079 4082 to 4083
 stp disable
\#
interface GigabitEthernet0/0/2
 port link-type trunk
 undo port trunk allow-pass vlan 1
 port trunk allow-pass vlan 2 to 4079 4082 to 4083
 stp disable
\#
interface GigabitEthernet0/0/3
 port link-type trunk
 undo port trunk allow-pass vlan 1
 port trunk allow-pass vlan 2 to 4081
 stp disable
\#
interface GigabitEthernet0/0/4
 port link-type trunk
 undo port trunk allow-pass vlan 1
 port trunk allow-pass vlan 2 to 4081
 stp disable
\#
return
**SW D:**
\#
vlan batch 2 to 4083
\#
rrpp enable
\#
stp region-configuration
 instance 1 vlan 4082 to 4083
 active region-configuration
\#
rrpp domain 1
 control-vlan 4082
 protected-vlan reference-instance 1
 timer hello-timer 2 fail-timer 7
 ring 1 node-mode transit primary-port GigabitEthernet0/0/1 secondary-port GigabitEthernet0/0/2 level 0
 ring 1 enable
\#
interface GigabitEthernet0/0/1
 port link-type trunk
 undo port trunk allow-pass vlan 1
 port trunk allow-pass vlan 2 to 4079 4082 to 4083
 stp disable
\#
interface GigabitEthernet0/0/2
 port link-type trunk
 undo port trunk allow-pass vlan 1
 port trunk allow-pass vlan 2 to 4079 4082 to 4083
 stp disable
\#
return
**SW E:**
\#
vlan batch 2 to 4083
\#
rrpp enable
\#
stp region-configuration
 instance 1 vlan 4082 to 4083
 active region-configuration
\#
rrpp domain 1
 control-vlan 4082
 protected-vlan reference-instance 1
 timer hello-timer 2 fail-timer 7
 ring 1 node-mode master primary-port GigabitEthernet0/0/1 secondary-port GigabitEthernet0/0/2 level 0
 ring 1 enable
\#
drop-profile default
\#
interface GigabitEthernet0/0/1
 port link-type trunk
 undo port trunk allow-pass vlan 1
 port trunk allow-pass vlan 2 to 4079 4082 to 4083
 stp disable
\#
interface GigabitEthernet0/0/2
 port link-type trunk
 undo port trunk allow-pass vlan 1
 port trunk allow-pass vlan 2 to 4079 4082 to 4083
 stp disable
\#
return
❤️ 3、验证：
**SW C：**
![2.jpg](https://img.hacpai.com/file/2019/11/2-a2e669bc.jpg)
![3.jpg](https://img.hacpai.com/file/2019/11/3-9825bf92.jpg)
![4.jpg](https://img.hacpai.com/file/2019/11/4-047c5aa4.jpg)




