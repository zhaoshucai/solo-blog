title: 网络互联基础-TCP连接的建立
date: '2019-11-08 16:42:42'
updated: '2019-11-08 16:42:42'
tags: [HUAWEI, ROS, RS, Cisco]
permalink: /articles/2019/11/08/1573206162209.html
---
1、TCP连接通过三次握手完成。 
client首先请求连接，发一个SYN包；
Server收到后回应SYN_ACK包；
Client收到后再 发ACK包。
established表示建立状态，当某端发出数据包后收到了回应则进入established状态。 
在TCP/IP连接时，如果两端都是established状态，则握手成功，否则是无连接或半联接状 态。 
2、套接字Socket 套接字Socket由协议、IP地址和端口号组成，套接字表示一路通讯，一般是一个服务，如 www服务是TCP的80端口，Telnet是TCP的23端口。
