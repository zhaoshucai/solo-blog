title: HUAWEI_WLAN_酒店项目
date: '2019-11-05 11:04:27'
updated: '2019-11-05 11:10:58'
tags: [HUAWEI, WLAN, Project]
permalink: /articles/2019/11/05/1572926667893.html
---
**实验要求**：
❤️ AP2与AP3同时广播work、guest网络信号。
**实验拓扑**：
![21.PNG](https://img.hacpai.com/file/2019/11/21-429963bc.PNG)
**实验配置参数：**
1、AP管理vlan为vlan11；管理网段为10.10.11.0/24
2、work工作vlan为vlan12；工作网段为10.10.12.0/24
3、guest工作vlan为vlan13；工作网段为10.10.13.0/24
4、公网模拟地址为101.101.101.101/32；位于LSW1的LoopBack0口
*实验设备配置详情*：
1、LSW1
\#
vlan batch 11 to 13
\#
interface Vlanif11
 ip address 10.10.11.1 255.255.255.0
\#
interface Vlanif12
 ip address 10.10.12.1 255.255.255.0
\#
interface Vlanif13
 ip address 10.10.13.1 255.255.255.0
\#
interface GigabitEthernet0/0/1
 port link-type trunk
 port trunk allow-pass vlan 11 to 13
\#
interface GigabitEthernet0/0/2
 port link-type trunk
 port trunk pvid vlan 11
 port trunk allow-pass vlan 11 to 13
\#
interface GigabitEthernet0/0/3
 port link-type trunk
 port trunk pvid vlan 11
 port trunk allow-pass vlan 11 to 13
\#
interface LoopBack0
 ip address 101.101.101.101 255.255.255.255
2、AC基本配置
vlan batch 11 to 13
\#
interface Vlanif11
 ip address 10.10.11.100 255.255.255.0
\#
interface Vlanif12
 ip address 10.10.12.100 255.255.255.0
\#
interface Vlanif13
 ip address 10.10.13.100 255.255.255.0
\#
interface GigabitEthernet0/0/1
 port link-type trunk
 port trunk allow-pass vlan 11 to 13
\#
ip route-static 0.0.0.0 0.0.0.0 10.10.11.1
3、AC模板配置
1、）配置AP组
[AC1]wlan
[AC1-wlan-view]ap-group name ap-group1
[AC1-wlan-ap-group- ap-group1]quit
2、）配置AP上线
A.配置各vlan地址池
 注意：AP地址池开启option 43选项
ip pool ap
 gateway-list 10.10.11.1
 network 10.10.11.0 mask 255.255.255.0
 dns-list 8.8.8.8 9.9.9.9
 option 43 sub-option 3 ascii 10.10.11.100
\#
ip pool work
 gateway-list 10.10.12.1
 network 10.10.12.0 mask 255.255.255.0
 dns-list 8.8.8.8 9.9.9.9
\#
ip pool guest
 gateway-list 10.10.13.1
 network 10.10.13.0 mask 255.255.255.0
 dns-list 8.8.8.8 9.9.9.9
B. 在vlanif接口下使能 DHCP功
interface Vlanif11
 ip address 10.10.11.100 255.255.255.0
 dhcp select global
\#
interface Vlanif12
 ip address 10.10.12.100 255.255.255.0
 dhcp select global
\#
interface Vlanif13
 ip address 10.10.13.100 255.255.255.0
 dhcp select global
3、）配置域管理模板
注意：此处域管理模板名称为domation
[AC1]wlan
[AC1 -wlan -view]regulatory -domain -profile name domain1
[AC1 -wlan -regulatory -domai n-prof -domain1]country -code CN
4、）配置 AC 源接口  源接口
[AC1]capwap source interface van 11
5、）配置 AP 认证方式  认证方式
[AC1]wlan
[AC1 -wlan -view]ap auth -mode mac -auth
[AC1 -wlan -view]ap -mac 4cfa -cabf -d0c0 ap -id 0
[AC1 -wlan -ap -1]ap -group ap -group
[AC1 -wlan -ap -1]ap -name ap1
3、配置WLAN业务参数
1、）配置SSID模板
[AC1]wlan
[AC1 -wlan -view]ssid -profile name work
[AC1 -wlan -ssid -prof -employee1]ssid work
[AC1 -wlan -ssid -prof -employee1]quit
[AC1 -wlan -view]ssid -profile name guest
[AC1 -wlan -ssid -prof -employee1]ssid guest
2、）创建VAP 模板，配置业务 VLAN用，并且引用SSID 模板。
注意：work的业务数据转发模式为直接转发，guest的业务数据转发模式为隧道转发。
[AC1 -wlan -view]vap -profile name work
[AC1 -wlan -vap -prof -voice1]forward -mode direct -forward
[AC1 -wlan -vap -prof -voice1]service -vlan vlan -id 12
[AC1 -wlan -vap -prof -voice1]ssid -profile work
[AC1 -wlan -vap -prof -voice1]quit
[AC1 -wlan -view]vap -profile name guest
[AC1 -wlan -vap -prof -guest1]forward -mode tunnel
[AC1 -wlan -vap -prof -guest1]service -vlan -id 13
[AC1 -wlan -vap -prof -voice1]ssid -profile guest
[AC1 -wlan -vap -prof -voice1]quit
3、）配置AP组引用域管理模板和VAP模板
注意：AP组“ap-group”，引用VAP模板“work”，设置VAP ID为“1”；引用VAP模板“guest”，设置VAP ID为“2”；AP上频射0和频射1都使用VAP模板的配置。
[AC1 -wlan -view]ap -group name ap -group
[AC1 -wlan -ap -group -ap -group]vap -profile work wlan 1 radio all
[AC1 -wlan -ap -group -ap -group]vap -profile gust wlan 2 radio all
[AC1 -wlan -ap -group -ap -group]regulatory -domain -profile domation
[AC1 -wlan -ap -group -ap -group]quit
**实验完结效果图**:
![实22.PNG](https://img.hacpai.com/file/2019/11/实22-dfe30141.PNG) 
**实验验证**:
1、STA1连接work测试101.101.101.101
![23.PNG](https://img.hacpai.com/file/2019/11/23-22b3e77b.PNG)
2、Cellphone1连接guest测试101.101.101.101
![24.PNG](https://img.hacpai.com/file/2019/11/24-bcce82c2.PNG)
~~ 实验数据仅供参考，具体请以真实环境为主！~~




