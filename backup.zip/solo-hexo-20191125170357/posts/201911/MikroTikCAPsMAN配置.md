title: MikroTik CAPsMAN 配置
date: '2019-11-21 09:58:41'
updated: '2019-11-21 10:04:05'
tags: [MikroTik, CAPsManager, Project]
permalink: /articles/2019/11/21/1574305121517.html
---
1、实验设备清单
CAPs Manager设备RB2011UiAS
CAP设备hAp ac
2、实验步骤
2.1、CAPs Manager设备配置
2.1.1、开启CAPs Manager
![1.jpg](https://img.hacpai.com/file/2019/11/1-ba6e01f1.jpg)
2.1.2、创建Channels模板
![2.jpg](https://img.hacpai.com/file/2019/11/2-03041395.jpg)
![3.jpg](https://img.hacpai.com/file/2019/11/3-7dab3683.jpg)
2.1.3、创建Datapths模板
![4.jpg](https://img.hacpai.com/file/2019/11/4-eb2cb927.jpg)
2.1.4、创建Security模板
![5.jpg](https://img.hacpai.com/file/2019/11/5-a4ae5640.jpg)
2.1.5、创建Configurations2.4G和5G模板，并在相应位置调用Channels、Datapaths、Security模板
![6.jpg](https://img.hacpai.com/file/2019/11/6-100b915a.jpg)
2.1.6、创建Provisioning2.4G和5G模板，并在相应位置分别调用2.4G和5G Configurations模板
![7.jpg](https://img.hacpai.com/file/2019/11/7-3487826d.jpg)
2.2、CAP设备配置
2.2.1、开启设备CAP功能
![CAP.jpg](https://img.hacpai.com/file/2019/11/CAP-2e9470cf.jpg)
2.3、CAP设备开启CAP功能后，设备将会自动重启。等待设备自动重启完毕。在CAPs Manager设备即自动发现CAP设备
![8.jpg](https://img.hacpai.com/file/2019/11/8-72e43539.jpg)














